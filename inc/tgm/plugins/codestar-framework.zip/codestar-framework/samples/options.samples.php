<?php if ( ! defined( 'ABSPATH' )  ) { die; } // Cannot access directly.

//
// Set a unique slug-like ID
//
$prefix = '_prefix_my_options';

//
// Create options
//
CSF::createOptions( $prefix, array(
  'menu_title' => 'Theme Options',
  'menu_slug'  => 'Coder_jibon',
) );

//
// header a section
//
CSF::createSection( $prefix, array(
  'title'  => 'Header Options',
  'icon'   => 'fas fa-heading',
  'fields' => array(

    array(
      'id'    => 'brand_logo',
      'type'  => 'media',
      'title' => 'Website Brand Logo',
      'url'   => false
    ),


     array(
      'id'      => 'secarch-opt',
      'type'    => 'switcher',
      'title'   => 'Search Options',
      'default' => true
    ),

  )
) );

//
// Post per Showing Category Basic
//
CSF::createSection( $prefix, array(
  'title'  => 'Post Category Showing  ',
  'icon'   => 'fas fa-bullhorn',
  'fields' => array(

    array(
      'id'    => '1st_category',
      'type'  => 'select',
      'title' => '1st category',
      'options' => all_category()
    ),
    array(
      'id'    => '2nd_category',
      'type'  => 'select',
      'title' => '2nd category',
      'options' => all_category()
    ),
    array(
      'id'    => '3th_category',
      'type'  => 'select',
      'title' => '3th category',
      'options' => all_category()
    ),
    array(
      'id'    => '4th_category',
      'type'  => 'select',
      'title' => '4th category',
      'options' => all_category()
    ),
    array(
      'id'    => '5th_category',
      'type'  => 'select',
      'title' => '5th category',
      'options' => all_category()
    ),
    array(
      'id'    => '6th_category',
      'type'  => 'select',
      'title' => '3th category',
      'options' => all_category()
    ),
    array(
      'id'    => '6th_category',
      'type'  => 'select',
      'title' => '3th category',
      'options' => all_category()
    ),
    array(
      'id'    => '7th_category',
      'type'  => 'select',
      'title' => '7th category',
      'options' => all_category()
    ),
    array(
      'id'    => '8th_category',
      'type'  => 'select',
      'title' => '8th category',
      'options' => all_category()
    ),
    array(
      'id'    => '9th_category',
      'type'  => 'select',
      'title' => '9th category',
      'options' => all_category()
    ),
    array(
      'id'    => '8th_category',
      'type'  => 'select',
      'title' => '8th category',
      'options' => all_category()
    ),
    array(
      'id'    => '9th_category',
      'type'  => 'select',
      'title' => '9th category',
      'options' => all_category()
    ),
    array(
      'id'    => '10th_category',
      'type'  => 'select',
      'title' => '10th category',
      'options' => all_category()
    ),

  )
) );

//
// header a section
//
CSF::createSection( $prefix, array(
  'title'  => 'Advertisement',
  'icon'   => 'fas fa-ad',
  'fields' => array(

    array(
      'id'    => 'banner1',
      'type'  => 'media',
      'title' => 'Banner One',
      'url'   => false
    ),
    array(
      'id'    => 'banner2',
      'type'  => 'media',
      'title' => 'Banner two',
      'url'   => false
    ),
    array(
      'id'    => 'banner3',
      'type'  => 'media',
      'title' => 'Banner three',
      'url'   => false
    ),
    array(
      'id'    => 'banner4',
      'type'  => 'media',
      'title' => 'Banner for',
      'url'   => false
    ),

  )
) );

//
// Follow @ Instagram
//
CSF::createSection( $prefix, array(
  'title'  => 'Follow Instagram Options',
  'icon'   => 'fab fa-instagram',
  'fields' => array(

    array(
      'id'    => 'institle',
      'type'  => 'text',
      'title' => 'Title',
    ),
    array(
      'id'    => 'code',
      'type'  => 'text',
      'title' => 'Instagram URl',
    ),

    array(
      'id'    => 'inscount',
      'type'  => 'gallery',
      'title' => 'Instagram Photo Gallery',
      'desc'  => 'Photo Image gallery'
    ),

  )
) );
//
// Footer a section
//
CSF::createSection( $prefix, array(
  'title'  => 'Footer Options',
  'icon'   => 'fab fa-foursquare',
  'fields' => array(

    array(
      'id'    => 'fburl',
      'type'  => 'text',
      'title' => 'Facebook URl',
      'default' => 'https://www.facebook.com/coderjb'
    ),
    array(
      'id'    => 'twiurl',
      'type'  => 'text',
      'title' => 'Twitter URl',
    ),
    array(
      'id'    => 'insurl',
      'type'  => 'text',
      'title' => 'instagram URl',
    ),
    array(
      'id'    => 'linkurl',
      'type'  => 'text',
      'title' => 'linkedin URl',
    ),

   
    array(
      'id'    => 'copy',
      'type'  => 'wp_editor',
      'title' => 'CopyRight Text',
      'media_buttons' => false,
      'default' => '<span>CJ © 2020  |  All Rights Reserved |  Developed By <a target="_blank" href="https://coderjibon.com">CoderJibon</a>|   01318-754392</span>'
    ),


  )
) );
