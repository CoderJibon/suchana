<?php if ( ! defined( 'ABSPATH' )  ) { die; } // Cannot access directly.

//
// Metabox of the PAGE
// Set a unique slug-like ID
//

$prefix_page_opts = '_prefix_page_options';



$prefix_page_opts = '_prefix_post_options';

//
// Create a metabox
//
CSF::createMetabox( $prefix_page_opts, array(
  'title'        => 'Home Slider Options',
  'post_type'    => 'home_slider',
  'show_restore' => true,
) );


CSF::createSection( $prefix_page_opts, array(
  'title'  => 'Slide Image',
  'icon'   => ' ',
  'fields' => array(
    array(
      'id'    => 'slideimage',
      'type'  => 'media',
      'title' => 'Add Image',
    ),
  )
) );
CSF::createSection( $prefix_page_opts, array(
  'title'  => 'Button',
  'icon'   => ' ',
  'fields' => array(
    array(
      'id'    => 'button',
      'type'  => 'group',
      'title' => 'Add New Button',
      'fields' => [
          [
            'id'    => 'tex',
            'type'  => 'text',
            'title' => 'Button Text'
          ],
          [
            'id'    => 'texurl',
            'type'  => 'text',
            'title' => 'Button URL:'
          ],
          [
            'id'    => 'texc',
            'type'  => 'color',
            'title' => 'Button Text Color:'
          ],
           [
            'id'    => 'texbc',
            'type'  => 'color',
            'title' => 'Button Background Color:'
          ],
      ]
    ),
  )
) );

